#include "jwt-cpp/jwt.h"

int main() {
	jwt::claim claim;
	return 0;
}

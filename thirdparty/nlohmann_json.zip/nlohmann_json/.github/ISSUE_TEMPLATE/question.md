---
name: Question
about: Ask a question regarding the library.
title: ''
labels: 'kind: question'
assignees: ''

---

- Describe what you want to achieve.

- Describe what you tried.

- Describe which system (OS, compiler) you are using.

- Describe which version of the library you are using (release version, develop branch).

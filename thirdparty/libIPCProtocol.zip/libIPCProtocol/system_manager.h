

#ifndef __SYSTEM_MANAGER_H__
#define __SYSTEM_MANAGER_H__

#ifdef __cplusplus
extern "C" {
#endif

#define SYSTEM_MANAGER "rockchip.system"
#define SYSTEM_MANAGER_PATH "/"
#define SYSTEM_MANAGER_INTERFACE SYSTEM_MANAGER ".server"

char *system_reboot(void);

#ifdef __cplusplus
}
#endif
#endif

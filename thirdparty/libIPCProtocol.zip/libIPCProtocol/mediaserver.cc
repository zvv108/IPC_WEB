

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>
#include <ctype.h>
#include <inttypes.h>

#include <glib.h>

#include <pthread.h>

#include "json-c/json.h"
#include "mediaserver.h"
#include "dbserver.h"

#include "mediaserver_proxy.h"
#include "dbus_connection.h"

#define MEDIA_DBUSSEND(path, interface, member, id, argout) \
    dbus_mutex_lock(); \
    try { \
        DBus::Connection conn = get_dbus_conn(); \
        auto proxy_ = std::make_shared<MediaControl>(conn, path, interface); \
        if (proxy_) \
          argout = proxy_->SetParam(member, id); \
    } catch (DBus::Error err) { \
        printf("DBus::Error - %s\n", err.what()); \
    } \
    dbus_mutex_unlock();

#define MEDIA_DBUSSEND_PARAM(path, interface, member, id, param, argout) \
    dbus_mutex_lock(); \
    try { \
        DBus::Connection conn = get_dbus_conn(); \
        auto proxy_ = std::make_shared<MediaControl>(conn, path, interface); \
        if (proxy_) \
          argout = proxy_->SetParam(member, id, param); \
    } catch (DBus::Error err) { \
        printf("DBus::Error - %s\n", err.what()); \
    } \
    dbus_mutex_unlock();



static struct KeyTable g_update_table[] = {
    { "TYPE",            "SetVideoConfig",            PARAM_TYPE_STRING,    ACTION_TYPE_SET},
};

/*
bitrate set in setBitRate
*/
static struct KeyTable g_encoder_table[] = {
    { "iGOP",            "SetGOP",            PARAM_TYPE_INT,    ACTION_TYPE_SET},
     { "iMaxRate",        "SetMaxRate",        PARAM_TYPE_INT,    ACTION_TYPE_SET},
    { "sFrameRate",      "SetFrameRate",      PARAM_TYPE_STRING, ACTION_TYPE_SET},
    { "sResolution",     "SetResolution",     PARAM_TYPE_STRING, ACTION_TYPE_RESET_PIPE},
    { "sRCQuality",      "SetRCQuality",      PARAM_TYPE_STRING, ACTION_TYPE_SET},
    { "sOutputDataType", "SetOutputDataType", PARAM_TYPE_STRING, ACTION_TYPE_RESET_PIPE},
    { "sStreamType",      "SetVideoType",      PARAM_TYPE_STRING, ACTION_TYPE_SET},
};


static int mediaserver_cmd(const char *path, const char *interface,
                           const char *cmd, int id)
{
    int ret;
    MEDIA_DBUSSEND(path, interface, cmd, id, ret);
    return ret;
}

static int mediaserver_cmd_int(const char *path, const char *interface,
                                const char *cmd, int id, int param)
{
    int ret;
    MEDIA_DBUSSEND_PARAM(path, interface, cmd, id, param, ret);
    return ret;
}

static int mediaserver_cmd_array(const char *path, const char *interface,
                                    const char *cmd, int id, void *param, int size)
{
    int ret;
    int32_t *values = (int32_t *)param;
    std::vector<int32_t> params;
    for (int i = 0; i < size; i++)
        params.push_back(values[i]);
    MEDIA_DBUSSEND_PARAM(path, interface, cmd, id, params, ret);
    return ret;
}

static int mediaserver_cmd_string(const char *path, const char *interface,
                                    const char *cmd, int id, const char *param)
{
    int ret;
    std::string params = param;
    MEDIA_DBUSSEND_PARAM(path, interface, cmd, id, params, ret);
    return ret;
}

static int mediaserver_cmd_array_dict(const char *path, const char *interface,
                                    const char *cmd, int id, const char *param)
{
    int ret;
    std::map<std::string, std::string> params;
    json_object *new_obj = json_tokener_parse(param);
    json_object_object_foreach(new_obj, key, val) {
        const char * value_str = json_object_get_string(val);
        params.emplace(key, value_str);
    }
    json_object_put(new_obj);
    MEDIA_DBUSSEND_PARAM(path, interface, cmd, id, params, ret);
    return ret;
}

static int find_method_index(struct KeyTable *table,int table_size,
                                  const char* key) {
    for (int index = 0; index < table_size; index++) {
        if (!strcmp(key, table[index].name))
			return index;
	}
	return -1;
}

static int find_need_reset_index(struct KeyTable *table, int table_size,
                                  const char* key) {
    for (int index = 0; index < table_size; index++) {
        if (!strcmp(key, table[index].name) &&
            table[index].action_type == ACTION_TYPE_RESET_PIPE) {
            return index;
        }
    }
    return -1;
}

static int do_mediaserver_cmd(const char * path, const char * interface,
                                const char * method, int type,
                                int id, const char* value_str) {
    int ret = 0;
    if (type == PARAM_TYPE_STRING) {
        ret = mediaserver_cmd_string(path, interface, method, id, value_str);
    } else if (type == PARAM_TYPE_INT) {
        int value = atoi(value_str);
        ret = mediaserver_cmd_int(path, interface, method, id, value);
    } else if (type == PARAM_TYPE_NONE) {
        ret = mediaserver_cmd(path, interface, method, id);
    } else if (type == PARAM_TYPE_ARRAY_DICT) {
        ret = mediaserver_cmd_array_dict(path, interface, method, id, value_str);
    }
    return ret;
}

static int do_mediaserver_set(const char * path, const char * interface,
                              struct KeyTable *table, int table_size,
                              int id, const char *data) {
    int ret = 0;
    json_object *new_obj = json_tokener_parse(data);
    json_object_object_foreach(new_obj, find_key, find_val) {    //把json分为 key与value
        const char * value_str = json_object_get_string(find_val);
        int index = find_need_reset_index(table, table_size, find_key);
        if (index >= 0) {
            const char * method = table[index].method;
            int type = table[index].param_type;
            ret = do_mediaserver_cmd(path, interface, method, type, id, value_str);
            json_object_put(new_obj);    //如果对json对象显式调用了json_object_get，之后必须成对调用json_object_put，否则将导致该json对象所占用内存泄漏
            return ret;
        }
    }
    json_object_object_foreach(new_obj, key, val) {
        const char * value_str = json_object_get_string(val);
        int index = find_method_index(table, table_size, key);
        if (index >= 0) {
            const char * method = table[index].method;
            int type = table[index].param_type;
            ret = do_mediaserver_cmd(path, interface, method, type, id, value_str);
        }
    }
    json_object_put(new_obj);
    return ret;
}




static int mediaserver_updt_set(int id, const char *data) {
  int ret = 0;
  int table_size = sizeof(g_update_table) / sizeof(struct KeyTable);
  ret = do_mediaserver_set(MEDIASERVER_ENCODER_PATH,
                           MEDIASERVER_ENCODER_INTERFACE,
                           g_update_table, table_size, id, data);
  return ret;
}


static int mediaserver_video_set(int id, const char *data) {
    int ret = 0;
    int table_size = sizeof(g_encoder_table) / sizeof(struct KeyTable);
	ret = do_mediaserver_set(MEDIASERVER_ENCODER_PATH,
		                     MEDIASERVER_ENCODER_INTERFACE,  
		                     g_encoder_table, table_size, id, data);
    return ret;
}



static int mediaserver_osd_set(int id, const char *data) {
    int ret = 0;
	ret = mediaserver_cmd_array_dict(MEDIASERVER_FEATURE_PATH,
                                 MEDIASERVER_FEATURE_INTERFACE,
	                             "SetOsd", id, data);
    return ret;
}


int mediaserver_update_set(int id, const char *data) {

  int ret = mediaserver_updt_set(id, data);
  return ret;
}


int mediaserver_set(char *table, int id, const char *data) {
    int ret = 0;

    if (!strcmp(table, TABLE_VIDEO)) {
		ret = mediaserver_video_set(id, data);
	} else if (!strcmp(table, TABLE_OSD)) {
		ret = mediaserver_osd_set(id, data);
        }
    return ret;
}



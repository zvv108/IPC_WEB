

#ifndef __MEDIASERVER_H__
#define __MEDIASERVER_H__

#ifdef __cplusplus
extern "C" {
#endif

enum ParamType {
    PARAM_TYPE_NONE = 0,
    PARAM_TYPE_INT,
    PARAM_TYPE_STRING,
    PARAM_TYPE_ARRAY,
    PARAM_TYPE_ARRAY_DICT,
    PARAM_TYPE_STRUCT,
};

enum ActionType {
    ACTION_TYPE_NONE = 0,
    ACTION_TYPE_SET,
    ACTION_TYPE_RESET_PIPE,
    ACTION_TYPE_REBOOT,
};

struct KeyTable {
    const char *name;
    const char *method;
    enum ParamType param_type;
    enum ActionType action_type;
};

int mediaserver_set(char *table, int id, const char *data);
int mediaserver_update_set(int id, const char *data);

#ifdef __cplusplus
}
#endif

#endif

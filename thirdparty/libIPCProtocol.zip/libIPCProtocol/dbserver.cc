#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <glib.h>
#include <dbus-c++/dbus.h>

#include "json-c/json.h"
#include "dbserver.h"
#include "dbserver_proxy.h"
#include "dbus_connection.h"

#define DBSERVER_DBUSSEND(FUNC) \
    char *ret = NULL; \
    dbus_mutex_lock(); \
    try { \
        DBus::Connection conn = get_dbus_conn(); \
        DBusDbServer* dbserver_proxy_ = new DBusDbServer(conn, DBSERVER_PATH, DBSERVER, interface); \
        auto config = dbserver_proxy_->FUNC(json); \
        ret = g_strdup(config.c_str()); \
        delete dbserver_proxy_; \
    } catch (DBus::Error err) { \
        printf("DBus::Error - %s\n", err.what()); \
    } \
    dbus_mutex_unlock(); \
    return ret;

char *dbserver_cmd(char *json, char *interface)
{
    DBSERVER_DBUSSEND(Cmd);
}

char *dbserver_sql(char *json, char *interface)
{
    DBSERVER_DBUSSEND(Sql);
}

extern "C" char *dbserver_system_user_add(char *username, char *password, int *authlevel, int *userlevel, int *fixed)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();
    json_object *data = json_object_new_object();
    if (username)
        json_object_object_add(data, "sUserName", json_object_new_string(username));
    if (password)
        json_object_object_add(data, "sPassword", json_object_new_string(password));
    if (authlevel)
        json_object_object_add(data, "iAuthLevel", json_object_new_int(*authlevel));
    if (userlevel)
        json_object_object_add(data, "iUserLevel", json_object_new_int(*userlevel));
    if (fixed)
        json_object_object_add(data, "iFixed", json_object_new_int(*fixed));

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_SYSTEM_USER));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", data);
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Insert"));

    json_config = (char *)json_object_to_json_string(j_cfg);
    ret = dbserver_cmd(json_config, (char *)DBSERVER_SYSTEM_INTERFACE);

    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_network_ipv4_set(char *interface, char *Method, char *Address, char *Netmask, char *Gateway)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();
    json_object *data = json_object_new_object();

    json_object_object_add(key, "sInterface", json_object_new_string(interface));
    if (Method)
        json_object_object_add(data, "sV4Method", json_object_new_string(Method));
    if (Address)
        json_object_object_add(data, "sV4Address", json_object_new_string(Address));
    if (Netmask)
        json_object_object_add(data, "sV4Netmask", json_object_new_string(Netmask));
    if (Gateway)
        json_object_object_add(data, "sV4Gateway", json_object_new_string(Gateway));

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_NETWORK_IP));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", data);
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_network_dns_set(char *interface, char *dns1, char *dns2)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();
    json_object *data = json_object_new_object();

    json_object_object_add(key, "sInterface", json_object_new_string(interface));
    if (dns1)
        json_object_object_add(data, "sDNS1", json_object_new_string(dns1));

    if (dns2)
        json_object_object_add(data, "sDNS2", json_object_new_string(dns2));

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_NETWORK_IP));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", data);
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_network_ip_get(char *interface)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();

    if (interface)
        json_object_object_add(key, "sInterface", json_object_new_string(interface));

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_NETWORK_IP));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", json_object_new_string("*"));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_network_power_get(char *type)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();

    if (type)
        json_object_object_add(key, "sType", json_object_new_string(type));

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_NETWORK_POWER));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", json_object_new_string("*"));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}



extern "C" char *dbserver_ntp_set(char *servers, char *timezone, char *timezonefile, char *timezonefiledst, int *autodst, int *automode, int *time)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();
    json_object *data = json_object_new_object();

    json_object_object_add(key, "id", json_object_new_int(0));
    if (servers)
        json_object_object_add(data, "sNtpServers", json_object_new_string(servers));
    if (timezone)
        json_object_object_add(data, "sTimeZone", json_object_new_string(timezone));
    if (timezonefile)
        json_object_object_add(data, "sTimeZoneFile", json_object_new_string(timezonefile));
    if (timezonefiledst)
        json_object_object_add(data, "sTimeZoneFileDst", json_object_new_string(timezonefiledst));
    if (autodst)
        json_object_object_add(data, "iAutoDst", json_object_new_int(*autodst));
    if (automode)
        json_object_object_add(data, "iAutoMode", json_object_new_int(*automode));
    if (time)
        json_object_object_add(data, "iRefreshTime", json_object_new_int(*time));

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_NTP));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", data);
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_ntp_get(void)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_NTP));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", json_object_new_string("*"));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_zone_get(void)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_ZONE));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", json_object_new_string("*"));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}
extern "C" char *dbserver_network_ip_set_id(char *json, int id)
{
    if (!json)
      return NULL;
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();
    json_object *data = json_tokener_parse(json);

    json_object_object_add(key, "id", json_object_new_int(id));

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_NETWORK_IP_MEDIA));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", data);
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
    json_object_put(j_cfg);

    return ret;

}


extern "C" char *dbserver_network_ip_get_id(void)
{
  char *ret = NULL;
  char *json_config;
  json_object *j_cfg = json_object_new_object();
  json_object *key = json_object_new_object();

  json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_NETWORK_IP_MEDIA));
  json_object_object_add(j_cfg, "key", key);
  json_object_object_add(j_cfg, "data", json_object_new_string("*"));
  json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

  json_config = (char *)json_object_to_json_string(j_cfg);

  ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
  json_object_put(j_cfg);

  return ret;
}
extern "C" char *dbserver_port_set(char *json, int id)
{
    if (!json)
        return NULL;
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();
    json_object *data = json_tokener_parse(json);

    json_object_object_add(key, "id", json_object_new_int(id));

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_PORT));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", data);
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_port_get(void)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();

    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_PORT));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", json_object_new_string("*"));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_NET_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_media_set(char *table, char *json, int id)
{
    if (!json)
        return NULL;
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();
    json_object *data = json_tokener_parse(json);

    json_object_object_add(key, "id", json_object_new_int(id));

    json_object_object_add(j_cfg, "table", json_object_new_string(table));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", data);
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_MEDIA_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_media_get(char *table)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();

    json_object_object_add(j_cfg, "table", json_object_new_string(table));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", json_object_new_string("*"));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_MEDIA_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_media_get_by_id(char *table, int id)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();

    json_object_object_add(key, "id", json_object_new_int(id));
    json_object_object_add(j_cfg, "table", json_object_new_string(table));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", json_object_new_string("*"));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_MEDIA_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_osd_get_by_id(char *table, int id)
{
  char *ret = NULL;
  char *json_config;
  json_object *j_cfg = json_object_new_object();
  json_object *key = json_object_new_object();

  json_object_object_add(key, "id", json_object_new_int(id));
  json_object_object_add(j_cfg, "table", json_object_new_string(table));
  json_object_object_add(j_cfg, "key", key);
  json_object_object_add(j_cfg, "data", json_object_new_string("*"));
  json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

  json_config = (char *)json_object_to_json_string(j_cfg);

  ret = dbserver_cmd(json_config, (char *)DBSERVER_MEDIA_INTERFACE);
  json_object_put(j_cfg);

  return ret;
}


char *dbserver_osd_get(void)
{
    char *ret = NULL;
    json_object *j_cfg = json_object_new_array();
    for (int i = 0; i < MAX_OSD_NUM; i++) {
        char *str = dbserver_media_get_by_id((char *)TABLE_OSD, i);
        json_object *j_ret = json_tokener_parse(str);
        json_object *j_data = json_object_object_get(j_ret, "jData");
        json_object *j_data_0 = json_object_array_get_idx(j_data, 0);
        json_object_array_add(j_cfg, json_object_get(j_data_0));
        if (str)
            g_free(str);
        json_object_put(j_ret);
    }

    ret = (char *)json_object_get_string(j_cfg);
    json_object_put(j_cfg);
    return ret;
}

char *dbserver_osd_ir_get(void)
{
  char *ret = NULL;
  json_object *j_cfg = json_object_new_array();
  for (int i = 0; i < MAX_OSD_NUM; i++) {
    char *str = dbserver_media_get_by_id((char *)TABLE_OSD_IR, i);
    json_object *j_ret = json_tokener_parse(str);
    json_object *j_data = json_object_object_get(j_ret, "jData");
    json_object *j_data_0 = json_object_array_get_idx(j_data, 0);
    json_object_array_add(j_cfg, json_object_get(j_data_0));
    if (str)
      g_free(str);
    json_object_put(j_ret);
  }
  ret = (char *)json_object_get_string(j_cfg);
  json_object_put(j_cfg);
  return ret;
}



extern "C" char *dbserver_video_set_id(char* json, int id)
{
  if (!json)
    return NULL;
  char *ret = NULL;
  char *json_config;
  json_object *j_cfg = json_object_new_object();
  json_object *key = json_object_new_object();
  json_object *data = json_tokener_parse(json);

  json_object_object_add(key, "id", json_object_new_int(id));

  json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_VIDEO));
  json_object_object_add(j_cfg, "key", key);
  json_object_object_add(j_cfg, "data", data);
  json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

  json_config = (char *)json_object_to_json_string(j_cfg);

  ret = dbserver_cmd(json_config, (char *)DBSERVER_MEDIA_INTERFACE);
  json_object_put(j_cfg);
  return ret;
}



extern "C" char *dbserver_video_flip_set_id(char* json, int id)
{
  if (!json)
    return NULL;
  char *ret = NULL;
  char *json_config;
  json_object *j_cfg = json_object_new_object();
  json_object *key = json_object_new_object();
  json_object *data = json_tokener_parse(json);

  json_object_object_add(key, "id", json_object_new_int(id));

  json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_VIDEO_FLIP));
  json_object_object_add(j_cfg, "key", key);
  json_object_object_add(j_cfg, "data", data);
  json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

  json_config = (char *)json_object_to_json_string(j_cfg);

  ret = dbserver_cmd(json_config, (char *)DBSERVER_MEDIA_INTERFACE);
  json_object_put(j_cfg);
  return ret;
}

extern "C" char *dbserver_video_get(void)
{
    return dbserver_media_get((char *)TABLE_VIDEO);
}

extern "C" char *dbserver_stream_url_set(char *json, int id)
{
    return dbserver_media_set((char *)TABLE_STREAM_URL, json, id);
}

extern "C" char *dbserver_stream_url_get(void)
{
    return dbserver_media_get((char *)TABLE_STREAM_URL);
}

extern "C" char *dbserver_system_set(char *table, char *json, int id)
{
    if (!json)
        return NULL;
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();
    json_object *data = json_tokener_parse(json);

    json_object_object_add(key, "id", json_object_new_int(id));

    json_object_object_add(j_cfg, "table", json_object_new_string(table));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", data);
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

    json_config = (char *)json_object_to_json_string(j_cfg);
    ret = dbserver_cmd(json_config, (char *)DBSERVER_SYSTEM_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_system_get(char *table)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object(); //json object JSON格式的数据结构,即“key-value”结构,其格式为“{"key1":value1,"key2",value2....}
    json_object *key = json_object_new_object();

    json_object_object_add(j_cfg, "table", json_object_new_string(table));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", json_object_new_string("*"));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));
    json_config = (char *)json_object_to_json_string(j_cfg);  //将struct json_object类型的json数据转化为字符串

    ret = dbserver_cmd(json_config, (char *)DBSERVER_SYSTEM_INTERFACE);
    json_object_put(j_cfg); //类似于free()函数，释放之前分配的new_object所占用的空间。

    return ret;
}


extern "C" void dbserver_system_user_delete(int id)
{
    char *ret = NULL;
    char *json_config;
    json_object *key = json_object_new_object();
    json_object *j_cfg = json_object_new_object();
    json_object_object_add(key, "id", json_object_new_int(id));
    json_object_object_add(j_cfg, "table", json_object_new_string(TABLE_SYSTEM_USER));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", json_object_new_string("*"));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Delete"));
    json_config = (char *)json_object_to_json_string(j_cfg);
    ret = dbserver_cmd(json_config, (char *)DBSERVER_SYSTEM_INTERFACE);

    json_object_put(j_cfg);
    if (ret)
        g_free(ret);
}



/*28181*/
extern "C" char* dbserver_gb28181_get(char *table)
{
  char *ret = NULL;
  char *json_config;
  json_object *j_cfg = json_object_new_object();
  json_object *key = json_object_new_object();

  json_object_object_add(j_cfg, "table", json_object_new_string(table));
  json_object_object_add(j_cfg, "key", key);
  json_object_object_add(j_cfg, "data", json_object_new_string("*"));
  json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));
  json_config = (char *)json_object_to_json_string(j_cfg);

  ret = dbserver_cmd(json_config, (char *)DBSERVER_MEDIA_INTERFACE);
  json_object_put(j_cfg);

  return ret;
}

extern "C" char *dbserver_gb28181_set(char *table, char *json, int id )
{
  char *ret = NULL;
  char *json_config;
  json_object *j_cfg = json_object_new_object();
  json_object *key = json_object_new_object();
  json_object *data = json_tokener_parse(json);

  json_object_object_add(key, "id", json_object_new_int(id));

  json_object_object_add(j_cfg, "table", json_object_new_string(table));
  json_object_object_add(j_cfg, "key", key);
  json_object_object_add(j_cfg, "data", data);
  json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

  json_config = (char *)json_object_to_json_string(j_cfg);

  ret = dbserver_cmd(json_config, (char *)DBSERVER_MEDIA_INTERFACE);
  json_object_put(j_cfg);

  return ret;
};

/*PTZ*/
extern "C" char* dbserver_ptz_get(char *table)
{
  char *ret = NULL;
  char *json_config;
  json_object *j_cfg = json_object_new_object();
  json_object *key = json_object_new_object();

  json_object_object_add(j_cfg, "table", json_object_new_string(table));
  json_object_object_add(j_cfg, "key", key);
  json_object_object_add(j_cfg, "data", json_object_new_string("*"));
  json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

  json_config = (char *)json_object_to_json_string(j_cfg);

  ret = dbserver_cmd(json_config, (char *)DBSERVER_MEDIA_INTERFACE);
  json_object_put(j_cfg);

  return ret;
}

extern "C" char *dbserver_ptz_set(char *table, char *json, int id )
{
  char *ret = NULL;
  char *json_config;
  json_object *j_cfg = json_object_new_object();
  json_object *key = json_object_new_object();
  json_object *data = json_tokener_parse(json);

  json_object_object_add(key, "id", json_object_new_int(id));

  json_object_object_add(j_cfg, "table", json_object_new_string(table));
  json_object_object_add(j_cfg, "key", key);
  json_object_object_add(j_cfg, "data", data);
  json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

  json_config = (char *)json_object_to_json_string(j_cfg);

  ret = dbserver_cmd(json_config, (char *)DBSERVER_MEDIA_INTERFACE);
  json_object_put(j_cfg);

  return ret;
};


extern "C" char *dbserver_event_set(char *table, char *json, int id)
{
    if (!json)
        return NULL;
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();
    json_object *data = json_tokener_parse(json);

    json_object_object_add(key, "id", json_object_new_int(id));

    json_object_object_add(j_cfg, "table", json_object_new_string(table));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", data);
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Update"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_EVENT_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_event_get(char *table)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();
    json_object *key = json_object_new_object();

    json_object_object_add(j_cfg, "table", json_object_new_string(table));
    json_object_object_add(j_cfg, "key", key);
    json_object_object_add(j_cfg, "data", json_object_new_string("*"));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Select"));

    json_config = (char *)json_object_to_json_string(j_cfg);

    ret = dbserver_cmd(json_config, (char *)DBSERVER_EVENT_INTERFACE);
    json_object_put(j_cfg);

    return ret;
}

extern "C" char *dbserver_drop_table(char *table, char *interface)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();

    json_object_object_add(j_cfg, "table", json_object_new_string(table));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Drop"));
    json_config = (char *)json_object_to_json_string(j_cfg);
    ret = dbserver_cmd(json_config, interface);
    json_object_put(j_cfg);
    return ret;
}

extern "C" char *dbserver_create_table(char *table, char *col, char *interface)
{
    char *ret = NULL;
    char *json_config;
    json_object *j_cfg = json_object_new_object();

    json_object_object_add(j_cfg, "table", json_object_new_string(table));
    json_object_object_add(j_cfg, "col", json_object_new_string(col));
    json_object_object_add(j_cfg, "cmd", json_object_new_string("Create"));
    json_config = (char *)json_object_to_json_string(j_cfg);
    ret = dbserver_cmd(json_config, interface);
    json_object_put(j_cfg);

    return ret;
}



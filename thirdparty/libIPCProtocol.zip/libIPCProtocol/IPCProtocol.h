

#ifndef __IPCPROTOCOL_H__
#define __IPCPROTOCOL_H__

#ifdef __cplusplus
extern "C" {
#endif

int IPCProtocol_init(void);
void IPCProtocol_deinit(void);

#ifdef __cplusplus
}
#endif

#endif
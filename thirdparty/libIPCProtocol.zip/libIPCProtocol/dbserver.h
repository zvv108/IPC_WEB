

#ifndef __DBSERVER_H
#define __DBSERVER_H

#ifdef __cplusplus
extern "C" {
#endif

#define DBSERVER  "rockchip.dbserver"
#define DBSERVER_PATH      "/"

#define DBSERVER_NET_INTERFACE  DBSERVER ".net"
#define DBSERVER_MEDIA_INTERFACE  DBSERVER ".media"
#define DBSERVER_SYSTEM_INTERFACE  DBSERVER ".system"
#define DBSERVER_EVENT_INTERFACE  DBSERVER ".event"
#define DS_SIGNAL_DATACHANGED   "DataChanged"

/* network */
#define TABLE_NETWORK_IP            "NetworkIP"
#define TABLE_NETWORK_SERVICE       "NetworkService"
#define TABLE_NETWORK_POWER         "NetworkPower"
#define TABLE_NTP                   "ntp"
#define TABLE_ZONE                  "zone"
#define TABLE_PORT                  "port"
#define TABLE_NETWORK_IP_MEDIA      "IPtoMeida"


/* media */
#define TABLE_VIDEO             "video"
#define TABLE_VIDEO_FLIP        "video_flip"
#define TABLE_VIDEO_ADVANCED_ENC "video_advanced_enc"
#define TABLE_VIDEO_REGION_CLIP "video_region_clip"
#define TABLE_AUDIO             "audio"
#define TABLE_STREAM_URL        "stream_url"

/* 28181 */
#define TABLE_28181_DEVICE_INFO         "GB28181DeviceInfo"
/* PTZ */
#define TABLE_PTZ_STATUS_INFO           "ptz_status_info"
#define TABLE_PTZ_AUX_INFO              "ptz_aux_info"
#define TABLE_PTZ_POSITION_INFO         "ptz_position_info"
#define TABLE_PTZ_CRUISE_INFO           "ptz_cruise_info"
#define TABLE_PTZ_CRUISE_CONDUCT        "ptz_cruise_conduct"

#define TABLE_IMAGE_SCENARIO            "image_scenario"
#define TABLE_IMAGE_ADJUSTMENT          "image_adjustment"
#define TABLE_IMAGE_EXPOSURE            "image_exposure"
#define TABLE_IMAGE_NIGHT_TO_DAY        "image_night_to_day"
#define TABLE_IMAGE_BLC                 "image_blc"
#define TABLE_IMAGE_WHITE_BLANCE        "image_white_blance"
#define TABLE_IMAGE_ENHANCEMENT         "image_enhancement"
#define TABLE_IMAGE_VIDEO_ADJUSTMEN     "image_video_adjustment"

#define TABLE_NORMALIZED_SCREEN_SIZE        "normalized_screen_size"
#define TABLE_IR_SCREEN_SIZE                "ir_screen_size"

#define TABLE_OSD_IR                        "osd_ir"
#define TABLE_OSD                           "osd"
#define TABLE_ROI                           "roi"
#define TABLE_MOVE_DETECTION                "MoveDetection"
#define TABLE_REGIONAL_INVASION             "RegionalInvasion"
#define TABLE_TEMPERATURE_DATA              "TemperatureData"
#define TABLE_TEMPERATURE_ALARM             "TemperatureAlarm"
#define TABLE_ALARM_DURATION                "AlarmDuration"

#define TABLE_FTP_CONFIG                    "FtpServer"
#define TABLE_ALARM_RULE                    "sAlarmRule"
#define TABLE_PROFILE                       "profile"
#define TABLE_METADATA                      "metadata"
#define TABLE_VIDEO_SOURCE                  "video_source"
#define TABLE_VIDEO_SOURCE_CONFIGURATION    "video_source_configuration"

/* system */
#define TABLE_SYSTEM_DEVICE_INFO        "SystemDeviceInfo"
#define TABLE_SYSTEM_SECRET_QUESTION    "SystemSecretQueston"
#define TABLE_SYSTEM_PARA               "SystemPara"
#define TABLE_SYSTEM_USER               "SystemUser"
#define TABLE_SYSTEM_DISCOVERY          "SystemDiscovery"
#define TABLE_SYSTEM_SCOPES             "SystemScopes"



/* event */
#define TABLE_EVENT_TRIGGERS            "EventTriggers"
#define TABLE_EVENT_SCHEDULES           "EventSchedules"
#define TABLE_SMART_COVER               "SmartCover"
#define TABLE_SMART_COVER_OVERLAY       "SmartCoverOverlay"



#define TYPE_VIDEO         0
#define TYPE_PHOTO         1
#define TYPE_BLACK_LIST    2
#define TYPE_SNAPSHOT      3
#define TYPE_WHITE_LIST    4
#define MAX_OSD_NUM        15

struct period
{
    int start_minute;
    int end_minute;
    char type[20];
};

struct day
{
    struct period day_period[8];
};

struct week
{
    struct day week_day[7];
};

struct DynamicLocation
{
    char *cap_name;
    char *dynamic_key;
    char *dynamic_val;
    char *target_key;
};

struct StaticLocation
{
    char *cap_name;
    char *target_key;
};

struct RangeJsonPara
{
    int min;
    int max;
    int step;
};


/* network */
char *dbserver_network_power_get(char *type);
char *dbserver_network_ipv4_set(char *interface, char *Method, char *Address, char *Netmask, char *Gateway);
char *dbserver_network_dns_set(char *interface, char *dns1, char *dns2);
char *dbserver_network_ip_get(char *interface);
char *dbserver_ntp_set(char *servers, char *timezone, char *timezonefile, char *timezonefiledst, int *autodst, int *automode, int *time);
char *dbserver_ntp_get(void);
char *dbserver_zone_get(void);
char *dbserver_port_set(char *json, int id);
char *dbserver_port_get(void);
char *dbserver_network_ip_set_id(char *json, int id);
char *dbserver_network_ip_get_id(void);

/* media */
char *dbserver_media_set(char *table, char *json, int id);
char *dbserver_media_get(char *table);
char *dbserver_media_get_by_id(char *table, int id);
char *dbserver_osd_get_by_id(char *table, int id);
char *dbserver_osd_get(void);
char *dbserver_osd_ir_get(void);
char *dbserver_video_set_id(char* json, int id);
char *dbserver_video_flip_set_id(char* json, int id);
char *dbserver_video_get(void);
char *dbserver_stream_url_set(char *json, int id);
char *dbserver_stream_url_get(void);

/* system */
char *dbserver_system_set(char *table, char *json, int id);
char *dbserver_system_get(char *table);
void dbserver_system_user_delete(int id);
char *dbserver_system_user_add(char *username, char *password, int *authlevel, int *userlevel, int *fixed);

/*28181*/
char *dbserver_gb28181_get(char *table);
char *dbserver_gb28181_set(char *table, char *json, int id );
char* dbserver_ptz_get(char *table);
char *dbserver_ptz_set(char *table, char *json, int id );

/* event */
char *dbserver_event_set(char *table, char *json, int id);
char *dbserver_event_get(char *table);

/* basic */
char *dbserver_sql(char *sql, char *interface);
char *dbserver_drop_table(char *table, char *interface);
char *dbserver_create_table(char *table, char *col, char *interface);

#ifdef __cplusplus
}
#endif

#endif
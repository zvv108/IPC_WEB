

#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unistd.h>
#include <glib.h>
#include <dbus-c++/dbus.h>

#include "json-c/json.h"
#include "system_manager.h"
#include "system_manager_proxy.h"
#include "dbus_connection.h"

#define SYSTEMMANAGER_DBUSSEND_1(FUNC) \
    dbus_mutex_lock(); \
    try { \
        DBus::Connection conn = get_dbus_conn(); \
        DBusSystemManager* system_manager_proxy_ = new DBusSystemManager(conn, SYSTEM_MANAGER_PATH, SYSTEM_MANAGER, SYSTEM_MANAGER_INTERFACE); \
        system_manager_proxy_->FUNC(); \
        delete system_manager_proxy_; \
    } catch (DBus::Error err) { \
        printf("DBus::Error - %s\n", err.what()); \
    } \
    dbus_mutex_unlock(); \
    return NULL;

#define SYSTEMMANAGER_DBUSSEND_2(FUNC) \
    char *ret = NULL; \
    dbus_mutex_lock(); \
    try { \
        DBus::Connection conn = get_dbus_conn(); \
        DBusSystemManager* system_manager_proxy_ = new DBusSystemManager(conn, SYSTEM_MANAGER_PATH, SYSTEM_MANAGER, SYSTEM_MANAGER_INTERFACE); \
        auto config = system_manager_proxy_->FUNC(json); \
        ret = g_strdup(config.c_str()); \
        delete system_manager_proxy_; \
    } catch (DBus::Error err) { \
        printf("DBus::Error - %s\n", err.what()); \
    } \
    dbus_mutex_unlock(); \
    return ret;

char *dbus_system_reboot(void)
{
    SYSTEMMANAGER_DBUSSEND_1(Reboot);
}


extern "C" char *system_reboot(void)
{
    return dbus_system_reboot();
}




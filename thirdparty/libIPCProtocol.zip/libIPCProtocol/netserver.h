

#ifndef __NETSERVER_H__
#define __NETSERVER_H__

#ifdef __cplusplus
extern "C" {
#endif

#define NETSERVER_BUS_NAME "rockchip.netserver"
#define NETSERVER_PATH "/"
#define NETSERVER_INTERFACE NETSERVER_BUS_NAME ".server"

#define NS_SIGNAL_POWERCHANGED    "PowerChanged"

void netserver_reboot(void);
char *netserver_get_service(char *type);
char *netserver_get_config(char *service);
char *netserver_get_networkip(char *interface);

#ifdef __cplusplus
}
#endif

#endif